#define _WINSOCK_DEPRECATED_NO_WARNINGS 
#define _CRT_SECURE_NO_WARNINGS
#ifndef SEVERTHREADPOOL_H
#define SEVERTHREADPOOL_H
#include<iostream>
#include<mutex>
#include<thread>
#include<queue>
#include<atomic>

using namespace std;
class SeverTask
{
public:
	virtual void run() = 0;
};
class SeverThreadPool
{
public:
	void push_task(SeverTask* task);
	static SeverThreadPool* Get_SeverThreadPool_Instance();
	int Get_CurTask_num();
private:
	atomic<int> thead_num_;
	static SeverThreadPool* instance;
	class clear
	{
	public:
		~clear() {
			if (instance)
				delete instance;
		}
	};
	SeverThreadPool();
	~SeverThreadPool();
	void work();
	vector<thread> threads;
	queue<SeverTask*> severtasks;
	atomic_bool running_flag_;
	condition_variable cv_;
	mutex mtx_;

};

#endif 

